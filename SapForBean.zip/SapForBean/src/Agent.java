import java.util.*;

public class Agent {


	private int matricule;
	private String nom;
	private String password;
	private List<UV> aptitude;
	private List<Integer> idSession;
	
	public Agent() {
		this.matricule = 0;
		this.nom = new String();
		this.aptitude = new ArrayList<UV>();
		this.idSession = new ArrayList<Integer>(); 
	}
	
	//Accesseurs et Modifieurs
	
	public int getMatricule() {
		return matricule;
	}
	
	public void setMatricule(int matricule) {
		this.matricule = matricule;
	}
	
	public String getNom() {
		return nom;
	}
	
	public void setNom(String nom) {
		this.nom = nom;
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<UV> getAptitude() {
		return aptitude;
	}
	
	public void setAptitude(List<UV> aptitude) {
		this.aptitude = aptitude;
	}

	public List<Integer> getIdSession() {
		return idSession;
	}

	public void setIdSession(List<Integer> idSession) {
		this.idSession = idSession;
	}

}
