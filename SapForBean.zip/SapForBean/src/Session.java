import java.util.*;

public class Session {
	private int id;
	private String nom;
	private String lieu;
	private int nbApprenant;
	private int nbFormateur;
	private int minApprenant;
	private int minFormateur;
	private List<Date> dates;
	private List<UV> prerequis;
	private Map<Integer, Integer> candidatsAp;
	private Map<Integer, Integer> candidatsFo;
	private Map<Integer, Boolean> apprenants;
	private Map<Integer, Boolean> formateurs;
	
	public Session() {
		this.id = 0;
		this.nom = new String();
		this.lieu = new String();
		this.nbApprenant = 0;
		this.minFormateur = 0;
		this.minApprenant = 0;
		this.minFormateur = 0;
		this.dates = new ArrayList<Date>();
		this.prerequis = new ArrayList<UV>();
		this.candidatsAp = new HashMap<Integer, Integer>();
		this.candidatsFo = new HashMap<Integer, Integer>();
		this.apprenants = new HashMap<Integer, Boolean>();
		this.formateurs = new HashMap<Integer, Boolean>();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getLieu() {
		return lieu;
	}

	public void setLieu(String lieu) {
		this.lieu = lieu;
	}

	public int getNbApprenant() {
		return nbApprenant;
	}

	public void setNbApprenant(int nbApprenant) {
		this.nbApprenant = nbApprenant;
	}

	public int getNbFormateur() {
		return nbFormateur;
	}

	public void setNbFormateur(int nbFormateur) {
		this.nbFormateur = nbFormateur;
	}

	public int getMinApprenant() {
		return minApprenant;
	}

	public void setMinApprenant(int minApprenant) {
		this.minApprenant = minApprenant;
	}

	public int getMinFormateur() {
		return minFormateur;
	}

	public void setMinFormateur(int minFormateur) {
		this.minFormateur = minFormateur;
	}

	public List<Date> getDates() {
		return dates;
	}

	public void setDates(List<Date> dates) {
		this.dates = dates;
	}

	public List<UV> getPrerequis() {
		return prerequis;
	}

	public void setPrerequis(List<UV> prerequis) {
		this.prerequis = prerequis;
	}

	public Map<Integer, Integer> getCandidatsAp() {
		return candidatsAp;
	}

	public void setCandidatsAp(Map<Integer, Integer> candidatsAp) {
		this.candidatsAp = candidatsAp;
	}

	public Map<Integer, Integer> getCandidatsFo() {
		return candidatsFo;
	}

	public void setCandidatsFo(Map<Integer, Integer> candidatsFo) {
		this.candidatsFo = candidatsFo;
	}

	public Map<Integer, Boolean> getApprenants() {
		return apprenants;
	}

	public void setApprenants(Map<Integer, Boolean> apprenants) {
		this.apprenants = apprenants;
	}

	public Map<Integer, Boolean> getFormateurs() {
		return formateurs;
	}

	public void setFormateurs(Map<Integer, Boolean> formateurs) {
		this.formateurs = formateurs;
	}


	
	
}
