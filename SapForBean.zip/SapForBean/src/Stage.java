import java.util.*;

public class Stage {

	private int id;
	private int directeur; // id Agent directeur
	private List<Integer> idSessions;
	
	public Stage() {
		this.id = 0;
		this.directeur = 0;
		this.idSessions = new ArrayList<Integer>();
	}

	// Accesseurs et Modifieurs
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public int getDirecteur() {
		return directeur;
	}
	
	public void setDirecteur(int directeur) {
		this.directeur = directeur;
	}
	
	public List<Integer> getIdSessions() {
		return idSessions;
	}
	
	public void setIdSessions(List<Integer> idSessions) {
		this.idSessions = idSessions;
	}
	
}
