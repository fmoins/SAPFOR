
public class UV {

	private int id;
	private String nom;
	private int niveau;

	public UV() {
		this.id = 0;
		this.nom = new String();
		this.niveau = 0;
	}

	//Accesseurs et Modifieurs
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public int getNiveau() {
		return niveau;
	}

	public void setNiveau(int niveau) {
		this.niveau = niveau;
	}
	
}
